import { Injectable, NotFoundException, BadRequestException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { OrderItem } from './entities/order-item.entity';
import { randomUUID } from 'crypto';
import { Ticket } from './entities/ticket.entity';
import { TicketPdfService } from './ticket-pdf.service';
import { Role, User } from '../user/entities/user.entity';

@Injectable()
export class TicketsService {
  constructor(
    @InjectRepository(Ticket) private readonly ticketsRepo: Repository<Ticket>,
    @InjectRepository(OrderItem) private readonly itemsRepo: Repository<OrderItem>,
    private readonly ticketPdfService: TicketPdfService,
  ) {}

  async generateForOrderItem(orderItemId: string, qty: number) {
    const item = await this.itemsRepo.findOne({ where: { id: orderItemId } });
    if (!item) throw new NotFoundException('Order item not found');

    const tickets: Ticket[] = [];
    for (let i = 0; i < qty; i++) {
      const t = this.ticketsRepo.create({
        orderItem: item,
        code: randomUUID(), // esto va al QR
        redeemedAt: null,
      });
      tickets.push(t);
    }
    return this.ticketsRepo.save(tickets);
  }

  async getByCode(code: string) {
    const t = await this.ticketsRepo.findOne({ where: { code } });
    if (!t) throw new NotFoundException('Ticket not found');
    return t;
  }

  async redeem(code: string) {
    const t = await this.getByCode(code);
    if (t.redeemedAt) throw new BadRequestException('Ticket ya redimido');
    t.redeemedAt = new Date();
    return this.ticketsRepo.save(t);
  }

  async findForUser(user: Pick<User, 'email'>) {
    if (!user?.email) {
      throw new BadRequestException('El usuario autenticado no tiene email asociado.');
    }

    return this.ticketsRepo
      .createQueryBuilder('ticket')
      .innerJoinAndSelect('ticket.orderItem', 'orderItem')
      .innerJoinAndSelect('orderItem.event', 'event')
      .innerJoinAndSelect('orderItem.ticketType', 'ticketType')
      .innerJoin('orderItem.order', 'order')
      .where('order.buyerEmail = :email', { email: user.email })
      .orderBy('ticket.createdAt', 'DESC')
      .getMany();
  }

  async getTicketPdfForUser(ticketId: string, user: User) {
    if (!user?.email) {
      throw new BadRequestException('El usuario autenticado no tiene email asociado.');
    }

    const ticket = await this.ticketsRepo
      .createQueryBuilder('ticket')
      .innerJoinAndSelect('ticket.orderItem', 'orderItem')
      .innerJoinAndSelect('orderItem.event', 'event')
      .innerJoinAndSelect('orderItem.ticketType', 'ticketType')
      .innerJoinAndSelect('orderItem.order', 'order')
      .where('ticket.id = :ticketId', { ticketId })
      .getOne();

    if (!ticket) {
      throw new NotFoundException('Ticket no encontrado');
    }

    const currentOrder = ticket.orderItem?.order;
    if (!currentOrder) {
      throw new NotFoundException('Orden asociada no encontrada');
    }
    const isAdmin = user.role === Role.ADMIN;
    if (!isAdmin && currentOrder?.buyerEmail !== user.email) {
      throw new ForbiddenException('No puedes descargar este ticket.');
    }

    return this.ticketPdfService.build(currentOrder, [ticket]);
  }
}
