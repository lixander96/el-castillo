import { OmitType, PartialType } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsOptional, ValidateNested } from 'class-validator';
import { CreateEventDto, UpdateTicketTypeDto } from './create-event.dto';

class UpdateEventBaseDto extends PartialType(OmitType(CreateEventDto, ['ticketTypes'] as const)) {}

export class UpdateEventDto extends UpdateEventBaseDto {
  @ValidateNested({ each: true })
  @Type(() => UpdateTicketTypeDto)
  @IsOptional()
  @IsArray()
  ticketTypes?: UpdateTicketTypeDto[];
}
