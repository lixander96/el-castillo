import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Event } from './entities/event.entity';
import { TicketType } from './entities/ticket-type.entity';
import { CreateEventDto } from './dto/create-event.dto';
import { UpdateEventDto } from './dto/update-event.dto';
import { OrderItem } from '../orders/entities/order-item.entity';

@Injectable()
export class EventsService {
  constructor(
    @InjectRepository(Event) private readonly eventsRepo: Repository<Event>,
    @InjectRepository(TicketType) private readonly ticketRepo: Repository<TicketType>,
  ) { }

  async findAll() {
    return this.eventsRepo.find({ order: { date: 'ASC', time: 'ASC' } });
  }

  async findOne(id: string) {
    const event = await this.eventsRepo.findOne({ where: { id } });
    if (!event) throw new NotFoundException('Event not found');
    return event;
  }

  async create(dto: CreateEventDto) {
    console.log("f")
    const event = await this.eventsRepo.save({
      ...dto,
      ticketTypes: dto.ticketTypes.map(t =>
        this.ticketRepo.create({
          ...t,
          available: typeof t.available === 'number' ? t.available : (t.total - (t.sold || 0)),
          sold: t.sold || 0,
        })
      ),
    });
    return event
    return this.eventsRepo.merge(event, dto);
  }

  async update(id: string, dto: UpdateEventDto) {
    const event = await this.findOne(id);
    // Update scalars
    this.eventsRepo.merge(event, dto);

    if (dto.ticketTypes) {
      const existingTickets = await this.ticketRepo.find({
        where: { event: { id: event.id } },
        relations: ['event'],
      });
      const existingMap = new Map(existingTickets.map((ticket) => [ticket.id, ticket]));

      const orderItemRepo = this.ticketRepo.manager.getRepository(OrderItem);
      const nextTickets: TicketType[] = [];

      for (const payload of dto.ticketTypes) {
        const payloadId = payload.id ? String(payload.id) : undefined;
        const total = Number(payload.total ?? (payloadId ? existingMap.get(payloadId)?.total ?? 0 : 0));
        if (total <= 0) {
          throw new BadRequestException(`La capacidad del ticket "${payload.name}" debe ser mayor a cero`);
        }

        const existing = payloadId ? existingMap.get(payloadId) : undefined;
        const currentSold = existing?.sold ?? Number(payload.sold ?? 0);
        const sold = Math.max(0, Math.min(total, Number(payload.sold ?? currentSold ?? 0)));
        const available = Math.max(
          0,
          Math.min(total - sold, Number(payload.available ?? (total - sold))),
        );

        if (existing) {
          existing.name = payload.name;
          existing.description = payload.description ?? null;
          existing.price = Number(payload.price);
          existing.total = total;
          existing.sold = sold;
          existing.available = available;
          existing.perks = payload.perks ?? null;
          nextTickets.push(existing);
          existingMap.delete(existing.id);
        } else {
          const created = this.ticketRepo.create({
            name: payload.name,
            description: payload.description ?? null,
            price: Number(payload.price),
            total,
            sold,
            available,
            perks: payload.perks ?? null,
            event,
          });
          nextTickets.push(created);
        }
      }

      const leftovers = Array.from(existingMap.values());
      if (leftovers.length) {
        const deletable: TicketType[] = [];
        const preserved: TicketType[] = [];

        for (const ticket of leftovers) {
          const references = await orderItemRepo.count({
            where: { ticketType: { id: ticket.id } },
          });
          if (references > 0) {
            preserved.push(ticket);
          } else {
            deletable.push(ticket);
          }
        }

        if (deletable.length) {
          await this.ticketRepo.remove(deletable);
        }

        nextTickets.push(...preserved);
      }

      event.ticketTypes = nextTickets;
    }
    return this.eventsRepo.save(event);
  }

  async remove(id: string) {
    await this.eventsRepo.delete(id);
    return { ok: true };
  }
}
