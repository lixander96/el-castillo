import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from './roles.decorator';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(ctx: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<string[]>(ROLES_KEY, [
      ctx.getHandler(),
      ctx.getClass(),
    ]);
    if (!required || required.length === 0) {
      return true;
    }

    const normalizedRequired = required
      .filter((role): role is string => typeof role === 'string' && role.length > 0)
      .map((role) => role.toUpperCase());

    if (!normalizedRequired.length) {
      return true;
    }

    const req = ctx.switchToHttp().getRequest();
    const userRole = `${req.user?.role ?? ''}`.toUpperCase();

    if (!userRole) {
      return false;
    }

    return normalizedRequired.includes(userRole);
  }
}
